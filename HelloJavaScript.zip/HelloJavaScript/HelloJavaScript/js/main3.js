﻿2 + 2;           // 4
"2" + "2";       // "22"
2 + 2 - 2;       // 2
"2" + "2" - "2"; // 20



/*var x = +0;
var y = -0;

console.log(typeof x); // Number
console.log(typeof y); // Number
console.log(x === y); // true
console.log(1 / x === 1 / y); // false

var z = 1 / 3;
console.log(z * 3);
*/