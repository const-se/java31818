﻿$("#header")
    .css({"font-size": "16px"})
    .animate({"font-size": "30px"}, 2000);

$("#result").click(function (e) {
    e.preventDefault();
    var n1 = parseInt($("#n1").val());
    var n2 = parseInt($("#n2").val());
    var result = n1 + n2;
    $(this).text(result);
});
$("#n1").keyup(function (e) {
    console.log(e);
    var n1 = parseInt($(this).val());
    $("#header").css({"font-size": n1 + "px"});
});

//$("#header").css({ color: "#080" });
// или
//var headers = $("#header");
//$(headers[0]).css({ color: "#080" });
// или
//headers.forEach(function (index, header) {
//    $(header).css({color: "#080"});
//});
// или на чистом JS
//document.getElementById("header").style.color = "#080";
