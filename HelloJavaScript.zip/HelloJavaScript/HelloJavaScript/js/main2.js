﻿function Fox() { }
Fox.prototype = { eat: true };
console.log(Fox);
console.log(Fox.prototype);

var fox = new Fox();
// fox.__proto__ = Fox.prototype;

delete Fox.prototype.eat;

console.log(fox.eat); // undefined
