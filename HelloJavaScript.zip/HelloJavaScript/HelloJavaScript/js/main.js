﻿var animal = {
    jumps: null,
    eat: function () {
        this.full = true;
    }
}
var fox = {
    jumps: true
};
fox.__proto__ = animal;

console.log(fox.jumps); // true

delete fox.jumps;
console.log(fox.jumps); // null

delete animal.jumps;
console.log(fox.jumps); // undefined

fox.eat();
console.log(fox);
