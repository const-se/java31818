package org.itstep;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(8080);

        while (true) {
            Socket socket = server.accept();
            handleClient(socket);
        }
    }

    private static void handleClient(Socket socket) throws IOException {
        Scanner input = new Scanner(socket.getInputStream());
        boolean firstLine = true;
        int emptyLines = 0;
        boolean css = false;

        do {
            String line = input.nextLine();

            if (firstLine) {
                String[] data = line.split(" ");

                if (data[1].contains("/styles.css")) {
                    css = true;
                }

                firstLine = false;
            }

            emptyLines += line.length() == 0 ? 1 : 0;
            System.out.println(line);
        } while (emptyLines < 1);

        PrintWriter output = new PrintWriter(socket.getOutputStream());
        String contentType = css
            ? "text/css"
            : "text/html; charset=UTF-8";
        output.println("HTTP/1.0 200 OK");
        output.println("Content-Type: " + contentType);
        output.println();
        output.println(createHtml(css));
        output.println();
        output.println();
        output.flush();

        socket.close();

        input.close();
        output.close();
    }

    private static String createHtml(boolean css) throws FileNotFoundException {
        String path = System.getProperty("user.dir")
            + File.separator + (css ? "styles.css" : "index.html");
        File file = new File(path);
        Scanner scanner = new Scanner(new FileInputStream(file));
        String html = "";

        while (scanner.hasNextLine()) {
            html += scanner.nextLine();
        }

        return html;
        // htmlbook.ru
        // KoMti23_
    }
}
