package org.itstep;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.PrintStream;
import java.sql.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class DatabaseReaderTest {
    private final String SQL = "SELECT * FROM test";

    private PrintStream out;
    private Connection connection;
    private Statement statement;
    private ResultSet result;
    private ResultSetMetaData metaData;

    @Before
    public void setUp() throws Exception {
        // Создаем фейковые объекты (моки)
        // Используем метод Mockito.mock(), в аргументы пишем класс объекта, который хотим замокать
        // Метод mock вернет нам уже готовый фиктивный объект того класса, который мы указали
        // ClassName.class - это мета-информация о классе (все его поля, методы и проч.)
        out = mock(PrintStream.class);
        connection = mock(Connection.class);
        statement = mock(Statement.class);
        result = mock(ResultSet.class);
        metaData = mock(ResultSetMetaData.class);

        when(metaData.getColumnCount()).thenReturn(2);
        // Для первого столбца будем возвращать тип VARCHAR, поэтому пишем 1
        when(metaData.getColumnType(1)).thenReturn(Types.VARCHAR);
        // Для второго столбца будем возвращать тип INTEGER, поэтому пишем 2
        when(metaData.getColumnType(2)).thenReturn(Types.INTEGER);

        // Если у мока result вызовут метод getMetaData, то он вернет фейковый мок metaData
        when(result.getMetaData()).thenReturn(metaData);
        when(result.next())
                // Короткая запись:
                // Для первых трех вызовов метода будем возвращать true,
                // а для последнего четвертого - false
                .thenReturn(true, true, true, false);
                // Длинная запись:
//                .thenReturn(true)
//                .thenReturn(true)
//                .thenReturn(true)
//                .thenReturn(false);
        when(result.getInt(2)).thenReturn(1991);
        when(result.getString(1)).thenReturn("Ivan");

        // Если у мока statement вызовут метод executeQuery, то он вернет фейковый мок result
        when(statement.executeQuery(SQL)).thenReturn(result);

        // Если у мока коннекта к БД вызовут метод createStatement, то он вернет мок statement
        when(connection.createStatement()).thenReturn(statement);
    }

    @Test
    public void readTable() throws SQLException {
        DatabaseReader reader = new DatabaseReader(out, connection);
        reader.readTable("test");

        // Проверим, что connection.createStatement будет вызван лишь один раз внутри reader.readTable()
        verify(connection, times(1)).createStatement();
        verify(statement, times(1)).executeQuery(SQL);
        verify(result, times(1)).getMetaData();
        verify(result, times(4)).next();
        verify(result, never()).getInt(1);
        verify(result, times(3)).getInt(2);
        verify(result, never()).getString(2);
        verify(result, times(3)).getString(1);
        verify(metaData, times(1)).getColumnCount();
        verify(metaData, times(3)).getColumnType(1);
        verify(metaData, times(3)).getColumnType(2);
        verify(out, times(3)).println();
        verify(out, times(3)).print("1991,");
        verify(out, times(3)).print("Ivan,");
    }
}
