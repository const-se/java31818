package org.itstep;

import org.junit.Test;
import org.mockito.Mockito;

import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.Assert.*;

public class MainTest {

    @Test
    public void main() throws SQLException {
        // Невозможно тестировать из-за использования статики внтури него
    }
}