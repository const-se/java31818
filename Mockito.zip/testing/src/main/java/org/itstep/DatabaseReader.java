package org.itstep;

import java.io.PrintStream;
import java.sql.*;

public class DatabaseReader {
    private PrintStream out;

    private Connection connection;

    /**
     * @param out Поток вывода, в который мы будем отправлять сообщения
     * @param connection Коннект к БД
     */
    public DatabaseReader(PrintStream out, Connection connection) {
        this.out = out;
        this.connection = connection;
    }

    /**
     * Чтение таблицы из БД
     * @param tableName Имя таблицы
     * @throws SQLException
     */
    public void readTable(String tableName) throws SQLException {
        // Сначала создаем "SQL-выражение", с помощью которого будем выполнять запрос к БД
        Statement statement = connection.createStatement();
        // Осуществляем SQL-запрос к БД, получаем результат - ResultSet (массив строк таблицы)
        ResultSet result = statement.executeQuery("SELECT * FROM " + tableName);
        // Получаем мета-данные о результате
        ResultSetMetaData metaData = result.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Пока есть следующая строчка таблицы результата
        while (result.next()) {
            // Проходим в цикле по каждому столбцу таблицы результата
            // Кол-во столбцов получаем из мета-данных результата
            for (int i = 1; i <= columnCount; i++) {
                // Выясняем тип столбца
                switch (metaData.getColumnType(i)) {
                    // Если тип столбца - целочисленный
                    case Types.INTEGER:
                        // Берем из ячейки строки целое число
                        out.print(result.getInt(i) + ",");
                        break;
                    // Если тип столбца - строчный
                    case Types.VARCHAR:
                        // Берем из ячейки строки строковое значение
                        out.print(result.getString(i) + ",");
                        break;
                }
            }
            out.println();
        }
    }
}
