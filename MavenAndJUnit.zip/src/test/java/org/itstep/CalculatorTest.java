package org.itstep;

import com.tngtech.java.junit.dataprovider.DataProvider;
import com.tngtech.java.junit.dataprovider.DataProviderRunner;
import com.tngtech.java.junit.dataprovider.UseDataProvider;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;

import static org.junit.Assert.*;

@RunWith(DataProviderRunner.class)
public class CalculatorTest {

    @DataProvider
    public static Object[][] provideCalcData() {
        return new Object[][] {
            {10.0, 15.0, "SUM", 25.0},
            {2.0, 2.0, "MULTI", 4.0},
            {20.0, 5.0, "SUB", 15.0},
            {9.0, 3.0, "DIV", 3.0}
        };
    }

    @Test
    @UseDataProvider("provideCalcData")
    public void calculate(Double a, Double b, String operation, Double expected) {
        // Тест по методологии AAA

        // Подготовка Arrange
        Calculator c = new Calculator();

        // Действие Act
        double result = c.calculate(a, b, Operation.valueOf(operation));

        // Проверка Assert
        Assert.assertEquals(expected, result, 0);
    }
}
