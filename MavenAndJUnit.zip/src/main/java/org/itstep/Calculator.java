package org.itstep;

public class Calculator {
    public double calculate(double a, double b, Operation op) {
//        Выкинет эксепшн, потому что константы SUUUUM в Operation нет
//        Operation op1 = Operation.valueOf("SUUUUM");
//        System.out.println(op1);
//        Но если передать валидное значение, то всё будет ОК
//        Operation op2 = Operation.valueOf("SUM");
//        System.out.println(op2);

        switch (op) {
            case SUM: return sum(a, b);
            case SUB: return sub(a, b);
            case MULTI: return multi(a, b);
            case DIV: return div(a, b);
        }

        return a;
    }

    private double sum(double a, double b) {
        return a + b;
    }

    private double sub(double a, double b) {
        return a - b;
    }

    private double multi(double a, double b) {
        return a * b;
    }

    private double div(double a, double b) {
        return a / b;
    }
}
