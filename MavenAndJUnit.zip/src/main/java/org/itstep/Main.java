package org.itstep;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        System.out.println(c.calculate(10, 15, Operation.DIV));
    }

    public static void db(String[] args) throws SQLException {
//        Connection connection = DriverManager.getConnection(
//            "jdbc:mysql://ensembldb.ensembl.org:3306",
//            "anonymous",
//            ""
//        );
//
//        System.out.println(connection.getClass().getName());
//        Statement statement = connection.createStatement();
//        ResultSet resultSet = statement.executeQuery("SHOW DATABASES");
//        statement.execute("CREATE SCHEMA itstep_example");
//
//        while (resultSet.next()) {
//            System.out.println(resultSet.getString(1));
//        }
//
//        connection.close();
    }
}
