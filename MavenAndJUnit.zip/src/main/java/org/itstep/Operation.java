package org.itstep;

public enum Operation {
    SUM,
    SUB,
    MULTI,
    DIV
}

//Operation a = Operation.SUM;
//Operation b = Operation.MULTI;
//
//public class Operation extends Enum {
//    public Operation(String name) {
//        this.name = name;
//    }
//}
//
//Operation a = new Operation("SUM");
