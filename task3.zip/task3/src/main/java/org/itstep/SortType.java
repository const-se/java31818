package org.itstep;

public enum SortType {
    /**
     * Сортировка по дате создания документа
     */
    CREATE_DATE,

    /**
     * Сортировка по имени файла документа
     */
    DOCUMENT_NAME
}
