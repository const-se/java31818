package org.itstep;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        CatalogManagerInterface catalogManager =
            new CatalogManager(System.getProperty("user.dir"));

        catalogManager.createCatalog("testCatalog");
    }
}
