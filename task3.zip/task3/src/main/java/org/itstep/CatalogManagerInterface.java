package org.itstep;

import java.io.IOException;

public interface CatalogManagerInterface {
    /**
     * Создать новую папку
     *
     * @param name Имя создаваемой папки
     * @throws IOException
     */
    void createCatalog(String name) throws IOException;

    /**
     * Вывести содержимое папки на экран
     */
    void readCatalog();

    /**
     * Отсортировать содержимое папки и вывести на экран
     *
     * @param type Тип сортировки @see {@link SortType}
     */
    void sort(SortType type);
}
