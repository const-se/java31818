package org.itstep;

import java.io.File;
import java.io.IOException;

public class CatalogManager implements CatalogManagerInterface {
    private String root;

    public CatalogManager(String root) {
        this.root = root;
    }

    /**
     * Создать новую папку
     *
     * @param name Имя создаваемой папки
     * @throws IOException
     */
    public void createCatalog(String name) throws IOException {
        File catalog = new File(root + File.separator + name);

        if (!catalog.exists()) {
            if (!catalog.mkdir()) {
                throw new IOException("Не удалось создать каталог");
            }
        }
    }

    /**
     * Вывести содержимое папки на экран
     */
    public void readCatalog() {

    }

    /**
     * Отсортировать содержимое папки и вывести на экран
     *
     * @param type Тип сортировки @see {@link SortType}
     */
    public void sort(SortType type) {

    }
}
