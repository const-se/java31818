package org.itstep;

import static org.junit.Assert.*;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

public class CatalogManagerTest {
    @Test
    public void createCatalog() throws IOException {
        String root = System.getProperty("user.dir");
        CatalogManagerInterface catalogManager =
            new CatalogManager(root);

        catalogManager.createCatalog("test123");

        File catalog = new File(root + File.separator + "test123");
        assertTrue(catalog.exists());
        catalog.delete();
    }
}
